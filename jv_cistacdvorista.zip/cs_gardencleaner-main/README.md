![217894339-62bf504a-ed86-4989-85a9-dfc18c3cafa0 (1)](https://user-images.githubusercontent.com/55330408/218249938-77209084-6464-468e-9fce-d2c30a275862.png)

# CScripts Garden Cleaner

For all support questions, ask in our [Discord](https://discord.gg/2kcXW3gRzg) support chat.

## Dependencies

- [QBCore](https://github.com/qbcore-framework/qb-core) or [ESX](https://github.com/esx-framework/esx_core)
- [oxmysql](https://github.com/overextended/oxmysql)
- Any third eye script

# Installation
* Download ZIP
* Drag and drop resource into your server files
* Start resource through server.cfg
* Restart your server.

# Preview
www.youtube.com/watch?v=baBViNtHwUM
