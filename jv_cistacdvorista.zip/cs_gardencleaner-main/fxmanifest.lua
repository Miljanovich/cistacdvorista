fx_version 'adamant'
game 'gta5'
lua54 'yes'
version '1.0.2'

server_scripts({
	'config/config.lua',
	'server/main.lua',
	'config/translations.lua',
})

client_scripts({
	'config/config.lua',
	'client/main.lua',
	'config/translations.lua',
})